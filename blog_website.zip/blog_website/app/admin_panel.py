from flask import Flask,render_template,url_for,redirect

app = Flask(__name__)

@app.route("/blog/admin", methods=["GET","POST"])

def admin_page():

    return render_template("admin_page.html")




if __name__ == "__main__":
    app.run(debug=True,port=8000)