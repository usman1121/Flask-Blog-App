from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,EmailField,SubmitField,TextAreaField,SearchField
from wtforms.validators import DataRequired,Email, Length,EqualTo
class RegisterForm(FlaskForm):
    name = StringField("Name",validators=[DataRequired()])
    email = EmailField("Email", validators=[DataRequired(), Email()])
    bio = StringField("About you",validators=[DataRequired()])
    password = PasswordField("Password" , validators=[DataRequired(),Length(min=5) ])
    submit = SubmitField("Register")
class LoginForm(FlaskForm):
    email = StringField("Email",validators=[DataRequired(), Email()])
    password = PasswordField("Password" , validators=[DataRequired(),Length(min=5) ])
    submit= SubmitField("Login")
class SearchForm(FlaskForm):
    search = SearchField("Seach ")
class EditForm(FlaskForm):
    name = StringField("Name")
    email = EmailField("Email", validators=[Email()])
    bio = StringField("About you")
    password = PasswordField("Password")
    password2 = PasswordField("Confirm Password" , validators=[EqualTo("password") ])
    submit = SubmitField("Save Changes")
class PostsForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(min=4, max=50)])
    content = TextAreaField("Content", validators=[DataRequired()])
    submit = SubmitField("Post")
class CommentForm(FlaskForm):
    content = TextAreaField("Add Comment", validators=[DataRequired()])
    submit = SubmitField("Comment")
class LikeDislikeForm(FlaskForm):
    like = SubmitField('Like')
    dislike = SubmitField('Dislike')

class ResetPassword(FlaskForm):
    email = EmailField("Email", validators=[Email()])
    password = PasswordField("New Password")
    password2 = PasswordField("Confirm Password" , validators=[EqualTo("password") ])
    submit = SubmitField("Save Changes")