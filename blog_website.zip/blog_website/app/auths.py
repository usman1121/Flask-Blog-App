from flask import Blueprint,render_template,redirect,url_for,flash,session
from .forms import RegisterForm,LoginForm,ResetPassword
from .models import Users,db
from flask_login import login_user, logout_user,current_user
auth_bp = Blueprint("auth_bp", __name__)

@auth_bp.route("/register", methods=["POST","GET"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        name = form.name.data
        bio = form.bio.data
        email = form.email.data
        password = form.password.data

        user = Users.query.filter_by(email=email).first()
        if user:
            flash("The Email is already exists","danger")
            return redirect(url_for("auth_bp.register"))
        new_user = Users(name=name, email=email,bio=bio)
        new_user.set_password_hash(password)
        db.session.add(new_user)
        db.session.commit()
        flash("The user Registered succesfull", "success")
        return redirect(url_for("auth_bp.login"))
    return render_template("register.html", form=form)



@auth_bp.route("/login", methods=["POST","GET"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data
        user = Users.query.filter_by(email=email).first()
        if not user:
            flash("No user with this email", "danger")
            return redirect(url_for("auth_bp.login"))
        if not user.check_password(password):
            flash("Invalid credentials", "danger")
            return redirect(url_for("auth_bp.login"))
        login_user(user)
        flash("Your logged in", "success")

        return redirect(url_for("routes_bp.home"))
    return render_template("login.html", form=form)



@auth_bp.route("/logout")
def logout():
    logout_user()
    flash("Logged out", "success")
    return redirect(url_for("auth_bp.login"))


@auth_bp.route("/password_reset",methods=["POST","GET"])
def password_reset():
    form = ResetPassword()
    user = Users.query.filter_by(email=form.email.data).first()
    if form.validate_on_submit():
        password = form.password.data
        password2 = form.password2.data
        user.password = password2

        flash("Password updated successfully", "success")
        return redirect(url_for("auth_bp.login"))
    flash("Password does not match ","danger")
    return render_template("password_reset.html",form=form)