from flask import Blueprint, render_template,flash,redirect,url_for,session,request
from .forms import PostsForm,CommentForm,EditForm
from .models import Posts,db,Comments,Likes,Users
from sqlalchemy import func
from datetime import datetime,timedelta
from flask_login import login_required,current_user
routes_bp = Blueprint("routes_bp", __name__)

@routes_bp.route("/", methods=["POST", "GET"])
def home():
    form = CommentForm()
    post_id = request.form.get('post_id')

    three_days_ago = datetime.utcnow() - timedelta(days=3)
    latest_posts = Posts.query.filter(Posts.published_at >= three_days_ago).order_by(Posts.published_at.desc()).limit(3).all()
    trending_posts = (
        Posts.query
        .outerjoin(Posts.post_likes)  
        .group_by(Posts.id)
        .order_by(func.sum(Likes.like.cast(db.Integer)).desc())
        .limit(6)
        .all()
    )

    if form.validate_on_submit():
        comment = form.content.data
        new_comment = Comments(content=comment, user_id=current_user.id, post_id=int(post_id))
        db.session.add(new_comment)
        db.session.commit()
        flash("Comment added successfully", "success")
        return redirect(url_for("routes_bp.home"))


    posts = Posts.query.options(db.joinedload(Posts.comments)).all()

    if request.method == "POST":
        action = request.form.get('action')
        post = Posts.query.get(post_id)

        existing_like = Likes.query.filter_by(post_id=post.id, user_id=current_user.id).first()

        if existing_like:
            if action == 'like':
                existing_like.like = True
            elif action == 'dislike':
                existing_like.like = False
        else:
            new_like = Likes(like=(action == 'like'), post_id=post.id, user_id=current_user.id)
            db.session.add(new_like)

        db.session.commit()
        flash("Your reaction has been updated", "success")
        return redirect(url_for("routes_bp.home"))

    return render_template(
        'index.html',
        form=form,
        posts=posts,
        latest_posts=latest_posts,
        trending_posts=trending_posts 
    )


@routes_bp.route("/blogs", methods=["POST","Get"])
@login_required
def blogs():
    form = PostsForm()
    if form.validate_on_submit():
        title = form.title.data
        content = form.content.data

        post = Posts.query.filter_by(title=title).first()
        if post:
            flash("The post already exists","danger")
            return redirect(url_for("routes_bp.blogs"))
        new_post = Posts(title=title,content=content,user_id=current_user.id)
        db.session.add(new_post)
        db.session.commit()
        flash("New post created successfuly", "success")
        return redirect(url_for("routes_bp.home"))
    return render_template("blogs.html", form=form)  
@routes_bp.route("/manage_posts", methods=["GET","POST"])
@login_required
def manage_posts():
    posts = Posts.query.filter_by(user_id=current_user.id)
    return render_template("manage_posts.html", posts=posts)


@routes_bp.route("/delete_posts/<int:post_id>", methods=["GET","POST"])
def delete_posts(post_id):
    post = Posts.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        flash("You are not authorized to delete this post!", "danger")
        return redirect(url_for("routes_bp.home"))
    Comments.query.filter_by(post_id=post.id).delete()
    db.session.delete(post)
    db.session.commit()
    flash("Post deleted successfuly", "success")
    return redirect(url_for("routes_bp.manage_posts"))


@routes_bp.route("/update_posts/<int:post_id>", methods=["GET","POST"])
def update_posts(post_id):
    post = Posts.query.get_or_404(post_id)
    form = PostsForm(obj=post)
    if form.validate_on_submit():
        post.title = form.title.data
        post.content = form.content.data
        db.session.commit()
        flash("Post is updated successfully", "success")
        return redirect(url_for("routes_bp.manage_posts"))
    return render_template("update_posts.html", form=form, posts=post)


@routes_bp.route("/search", methods=["GET","POST"])
def search():
    form = CommentForm()
    post_id = request.form.get('post_id')
    if form.validate_on_submit():
        comment = form.content.data
        new_comment = Comments(content=comment, user_id=current_user.id, post_id=int(post_id))
        db.session.add(new_comment)
        db.session.commit()
        flash("Comment added successfully", "success")
        return redirect(url_for("routes_bp.search"))

    posts = Posts.query.options(db.joinedload(Posts.comments)).all()
    if request.method == "POST":
        action = request.form.get('action') 
        post = Posts.query.get(post_id)
        existing_like = Likes.query.filter_by(post_id=post.id, user_id=current_user.id).first()
        if existing_like:
            if action == 'like':
                existing_like.like = True
            elif action == 'dislike':
                existing_like.like = False
        else:
            new_like = Likes(like=(action == 'like'), post_id=post.id, user_id=current_user.id)
            db.session.add(new_like)
        db.session.commit()
        flash("Your reaction has been updated", "success")
        return redirect(url_for("routes_bp.search"))
    query = request.args.get("query", "").strip() 
    results = []
    if query:
        results = Posts.query.filter(
            (Posts.title.ilike(f"%{query}%")) | (Posts.content.ilike(f"%{query}%"))
        ).all()
    return render_template("search_results.html", results=results, query=query,form=form)

@routes_bp.route("/edit_profile", methods=["GET","POST"])
def edit_profile():
    user = Users.query.filter_by(id = current_user.id).first()
    form = EditForm(obj=user)
    if form.validate_on_submit():
        user.name = form.name.data
        user.email = form.email.data
        user.bio = form.bio.data
        user.password = form.password.data
        user.set_password_hash(form.password2.data)
        db.session.commit()
        flash("Profile is updated successfully", "success")
        return redirect(url_for("routes_bp.edit_profile"))

    return render_template("edit_profile.html", form=form)