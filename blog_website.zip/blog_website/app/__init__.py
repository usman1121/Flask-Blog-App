from flask import Flask
from flask_login import LoginManager
from flask_moment import Moment
from .models import db,Users
from .routes import routes_bp
from .auths import auth_bp
def create_app():  
    app = Flask(__name__)
    moment = Moment(app)
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///blogs.db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["SECRET_KEY"] = "udhsudhsdsudsdsdusdbshndsd"
    db.init_app(app)
    
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view  = 'auth_bp.login'
    @login_manager.user_loader
    def load_user(user_id):
        return Users.query.get(int(user_id)) 
    app.register_blueprint(routes_bp)
    app.register_blueprint(auth_bp)

    return  app, db
