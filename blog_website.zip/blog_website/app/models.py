from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash,check_password_hash
db = SQLAlchemy()
class Users(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), nullable=False, unique=True)
    bio = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(20), nullable=False, unique=True)
    password = db.Column(db.String(30), nullable=False)
    role = db.Column(db.String(10), nullable=False, default="user")
    def set_password_hash(self, password):
        self.password = generate_password_hash(password)
    def check_password(self, password):
        return check_password_hash(self.password , password)
class Posts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(1000), nullable=False)
    content = db.Column(db.String(1000), nullable=False)
    published_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    user = db.relationship("Users", backref="posts", lazy=True)
    def get_likes_count(self):
        return len([like for like in self.post_likes if like.like])
    def get_dislikes_count(self):
        return len([like for like in self.post_likes if not like.like])
    

class Comments(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(1000), nullable=False)
    published_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    post = db.relationship('Posts', backref='comments', lazy=True)
    post_id = db.Column(db.Integer, db.ForeignKey("posts.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    user = db.relationship('Users', backref='comments', lazy=True)  # Relationship to
    
class Likes(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=False)
    like = db.Column(db.Boolean, nullable=False)  # True for like, False for dislike
    user = db.relationship('Users', backref=db.backref('post_likes', lazy=True))
    post = db.relationship('Posts', backref=db.backref('post_likes', lazy=True))
